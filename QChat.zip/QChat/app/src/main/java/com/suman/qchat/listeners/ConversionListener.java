package com.suman.qchat.listeners;

import com.suman.qchat.models.User;

public interface ConversionListener {
    void onConversionCLicked(User user);
}
